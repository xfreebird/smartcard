# Cursor: eSemnBun

This is a configuration fragment, not an installer. Merge only the esemnbun server into
an existing configuration; preserve other servers and settings. Copy the instruction file
to the indicated workspace location. For Claude Desktop, paste the instruction body into
Project instructions (or attach it in the conversation); it is not an auto-loaded skill.
For Windsurf use Open MCP config file and merge there; the filename here is a fragment.
For Cline use MCP Servers > Configure MCP Servers. See the guide for global config locations.

The configured executable/root must already exist on the machine running the agent.
Exporting does not validate executable identity, directory permissions or symlink ancestry.
Check installed version, canonical physical paths and private broker permissions first.
No broker argument means offline verification only; signing needs separate setup.
The export never enables unattended signing, changes host permissions or stores PINs.

Restart/reload the client, trust the server configuration, list tools, and call capabilities.
Verify a fictional signed fixture before real use. Legacy clients must negotiate 2025-11-25;
modern clients must support 2026-07-28. Older revisions are rejected, not downgraded.
Configuration is based on official documentation; end-to-end client validation is pending.

Full guide: https://esemnbun.md/docs/integrations/mcp-agents/
Policy: https://esemnbun.md/packages/mcp.md
